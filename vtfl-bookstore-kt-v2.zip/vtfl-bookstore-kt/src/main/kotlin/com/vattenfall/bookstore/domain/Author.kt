package com.vattenfall.bookstore.domain

data class Author(
    val id: Int,
    val name: String,
    val surname: String
)