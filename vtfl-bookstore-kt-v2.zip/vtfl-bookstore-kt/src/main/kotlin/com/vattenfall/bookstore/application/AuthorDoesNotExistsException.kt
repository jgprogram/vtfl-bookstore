package com.vattenfall.bookstore.application

class AuthorDoesNotExistsException : Exception()
